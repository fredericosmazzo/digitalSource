DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_alterar_status`(IN `pidusuario` INT, IN `pstatus` INT)
BEGIN
	UPDATE `usuarios` SET `status`=`pstatus` WHERE `idusuario` = `pidusuario`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_excluir_permissao4`(IN `pidgrupo` INT, IN `pnomegrupo` VARCHAR(255), IN `ptabela` VARCHAR(255))
BEGIN
SET @GRUPO = pidgrupo;
SET @NOME =  pnomegrupo;
SET @SQL = CONCAT('DELETE FROM ',CONCAT(ptabela),' WHERE grupoidpermissao = @GRUPO');
PREPARE stmt FROM @SQL;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_alterar_usuario`(IN `pidusuario` INT, IN `pgrupo` INT, IN `pcargo` INT, IN `psetor` INT)
BEGIN
	UPDATE `usuarios` SET `grupo`=`pgrupo`, `cargo`=`pcargo`, `setor`=`psetor` WHERE `idusuario` = `pidusuario`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_excluir_grupo`(IN `pidgrupo` INT)
BEGIN
	SET @tabela = (SELECT LOWER(nomegrupo) FROM grupos WHERE idgrupo = pidgrupo);
    SET @SQL = CONCAT('DROP TABLE ',CONCAT(@tabela));
	PREPARE stmt FROM @SQL;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
    DELETE FROM `grupos` WHERE idgrupo = pidgrupo;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_excluir_cargo`(IN `pidcargo` INT)
BEGIN
	DELETE FROM `cargos` WHERE idcargo = pidcargo;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_inserir_novo_usuario`(IN `pnome` VARCHAR(155) CHARSET utf8, IN `pdatanascimento` DATE, IN `pemail` VARCHAR(155) CHARSET utf8, IN `pdocumento` VARCHAR(25) CHARSET utf8, IN `pcelular` VARCHAR(25) CHARSET utf8, IN `pusuario` VARCHAR(25) CHARSET utf8, IN `psenha` VARCHAR(25) CHARSET utf8, IN `pstatus` INT)
BEGIN
IF((SELECT COUNT(`idusuario`) AS total FROM `usuarios` WHERE CAST(AES_DECRYPT(`nome`,'procon1234') AS char(255)) = `pnome` AND CAST(AES_DECRYPT(`documento`,'procon1234') AS char(255)) = `pdocumento` AND CAST(AES_DECRYPT(`celular`,'procon1234') AS char(255)) = `pcelular` AND CAST(AES_DECRYPT(`email`,'procon1234') AS char(255))=`pemail`) = 0) THEN
	INSERT INTO `usuarios`
			(	`nome`,
				`datanascimento`,
				`email`,
				`documento`,
				`celular`,
				`usuario`,
				`senha`,
                `status`)
	VALUES 	(
    			`pnome`,
    			`pdatanascimento`,
		       	`pemail`,
		        `pdocumento`,
		        `pcelular`,
		        `pusuario`,
		        `psenha`,
                `pstatus`
			);
END IF;
UPDATE `usuarios`
SET `nome`= AES_ENCRYPT(`nome`,'procon1234'),
    `email`= AES_ENCRYPT(`email`,'procon1234'),
    `documento`= AES_ENCRYPT(`documento`,'procon1234'),
    `celular`= AES_ENCRYPT(`celular`,'procon1234'),
    `usuario`= AES_ENCRYPT(`usuario`,'procon1234'),
    `senha`= AES_ENCRYPT(`senha`,'procon1234')
WHERE idusuario = last_insert_id();

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_cadastro`(IN `pa` INT, IN `pb` INT, IN `pc` INT)
    NO SQL
IF((SELECT COUNT(id) FROM teste2 WHERE a = pa) = 0) THEN
SET @retorno := 1;
SELECT @retorno;
ELSEIF((SELECT COUNT(id) FROM teste2 WHERE b = pb) = 0) THEN
SET @retorno := 1;
SELECT @retorno;
ELSEIF((SELECT COUNT(id) FROM teste2 WHERE c = pc) = 0) THEN
SET @retorno := 1;
SELECT @retorno;
ELSE
INSERT INTO teste (a, b, c) VALUES (pa, pb, pc);
END IF$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_cadastro_familiar`(IN `pnis_beneficiario` VARBINARY(255), IN `pnome` VARBINARY(255), IN `pdatanascimento` DATE, IN `pcpf` VARBINARY(255), IN `pnis` VARBINARY(255), IN `prenda` INT, IN `pbolsafamilia` INT, IN `pbpc` INT)
    NO SQL
BEGIN
INSERT INTO `composicao_familiar`(`nis_beneficiario`, `nome`, `datanascimento`, `cpf`, `nis`, `renda`, `bolsafamilia`, `bpc`) VALUES (pnis_beneficiario, pnome, pdatanascimento, pcpf, pnis, prenda, pbolsafamilia, pbpc);

UPDATE `composicao_familiar` SET `nis_beneficiario`= AES_ENCRYPT(`nis_beneficiario`,'semas2021'), `nome`= AES_ENCRYPT(`nome`,'semas2021'), `cpf`= AES_ENCRYPT(`cpf`,'semas2021'), `nis`= AES_ENCRYPT(`nis`,'semas2021') WHERE id_registro = last_insert_id();

UPDATE `composicao_familiar` SET `idade`=(SELECT FLOOR((PERIOD_DIFF(DATE_FORMAT(now(),'%Y%m'),DATE_FORMAT(`datanascimento`,'%Y%m')))/12) AS IDADE FROM `composicao_familiar`)  WHERE id_registro = last_insert_id();
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_nova_permissao2`(IN `pidgrupo` INT, IN `pnomegrupo` VARCHAR(255), IN `pcontrole` INT)
BEGIN
IF(pcontrole = 1) THEN
	IF((SELECT COUNT(`idpermisao`) AS total FROM `permissao_gestao` WHERE `grupoidpermissao` = `pidgrupo`) = 0) THEN
	INSERT INTO `permissao_gestao`(`grupoidpermissao`, `grupopermisao`) VALUES (`pidgrupo`, `pnomegrupo`);
    END IF;
END IF;
IF(pcontrole = 2) THEN
	IF((SELECT COUNT(`idpermisao`) AS total FROM `permissao_atendimento` WHERE `grupoidpermissao` = `pidgrupo`) = 0) THEN
	INSERT INTO `permissao_atendimento`(`grupoidpermissao`, `grupopermisao`) VALUES (`pidgrupo`, `pnomegrupo`);
    END IF;
END IF;
IF(pcontrole = 3) THEN
	IF((SELECT COUNT(`idpermisao`) AS total FROM `permissao_audiencia` WHERE `grupoidpermissao` = `pidgrupo`) = 0) THEN
	INSERT INTO `permissao_audiencia`(`grupoidpermissao`, `grupopermisao`) VALUES (`pidgrupo`, `pnomegrupo`);
    END IF;
END IF;
IF(pcontrole = 4) THEN
	IF((SELECT COUNT(`idpermisao`) AS total FROM `permissao_fiscalizacao` WHERE `grupoidpermissao` = `pidgrupo`) = 0) THEN
	INSERT INTO `permissao_fiscalizacao`(`grupoidpermissao`, `grupopermisao`) VALUES (`pidgrupo`, `pnomegrupo`);
    END IF;
END IF;
IF(pcontrole = 5) THEN
	IF((SELECT COUNT(`idpermisao`) AS total FROM `permissao_administrativo` WHERE `grupoidpermissao` = `pidgrupo`) = 0) THEN
	INSERT INTO `permissao_administrativo`(`grupoidpermissao`, `grupopermisao`) VALUES (`pidgrupo`, `pnomegrupo`);
    END IF;
END IF;
IF(pcontrole = 6) THEN
	IF((SELECT COUNT(`idpermisao`) AS total FROM `permissao_coordenacao` WHERE `grupoidpermissao` = `pidgrupo`) = 0) THEN
	INSERT INTO `permissao_coordenacao`(`grupoidpermissao`, `grupopermisao`) VALUES (`pidgrupo`, `pnomegrupo`);
    END IF;
END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_excluir_permissao`(IN `pidgrupo` INT, IN `pnomegrupo` VARCHAR(255), IN `ptabela` VARCHAR(255))
BEGIN
SET @GRUPO = pidgrupo;
SET @NOME =  pnomegrupo;
SET @SQL = CONCAT('DELETE FROM ',CONCAT(ptabela),' WHERE grupoidpermissao = @GRUPO AND grupopermisao = @NOME');
PREPARE stmt FROM @SQL;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_novo_cargo`(IN `pnomecargo` VARCHAR(255))
BEGIN
IF(pnomecargo !='') THEN
	INSERT INTO cargos (nomecargo) VALUES (pnomecargo);
END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_protocolo_entrada`(IN `ptipo_documento` INT, IN `pnum_documento` VARCHAR(125) CHARSET utf8, IN `plocal_origem` INT, IN `preferencia` TEXT CHARSET utf8, IN `pcadastrante` INT)
BEGIN
	INSERT INTO `documentos_protocolo`(
										`tipo_documento`,
										`num_documento`,
										`local_origem`,
										`referencia`,
										`cadastrante`)
VALUES (
			ptipo_documento,
			pnum_documento,
			plocal_origem,
			preferencia,
			pcadastrante);
    INSERT INTO `entrada_protocolo`(`documento_id`,`local_origem`, `local_destino`,`cadastrante`) 
    VALUES ((SELECT documentos_protocolo.documento_id FROM documentos_protocolo WHERE documentos_protocolo.documento_id = last_insert_id()), plocal_origem, 1, pcadastrante);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_novo_local_protocolo`(IN `porigem` VARCHAR(255))
BEGIN
IF(porigem !='') THEN
	INSERT INTO `locais_origem`(`origem`) VALUES (porigem);
    INSERT INTO `locais_protocolo`(`destino`) VALUES (porigem);
END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_nova_permissao`(IN `pidgrupo` INT, IN `pnomegrupo` VARCHAR(255), IN `ptabela` VARCHAR(255))
BEGIN
SET @GRUPO = pidgrupo;
SET @NOME =  pnomegrupo;
SET @SQL = CONCAT('INSERT INTO ',CONCAT(ptabela),'(`grupoidpermissao`, `grupopermisao`) VALUES(@GRUPO, @NOME)');
PREPARE stmt FROM @SQL;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_novo_grupo`(IN `pnomegrupo` VARCHAR(255))
BEGIN
IF(pnomegrupo !='') THEN
	INSERT INTO grupos (nomegrupo) VALUES (pnomegrupo);
END IF;
CALL sp_tabela(pnomegrupo);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_cadastro_beneficio`(
	IN `pnis` VARBINARY(255),
	IN `pnome` VARBINARY(255),
	IN `pdatanascimento` DATE,
	IN `pcpf` VARBINARY(255),
	IN `pemail` VARBINARY(255),
	IN `ptelefone` VARBINARY(255),
	IN `pcep` VARCHAR(30),
	IN `pendereco` VARCHAR(255),
	IN `pnumero` VARCHAR(50),
	IN `pcomplemento` VARCHAR(50),
	IN `pbairro` VARCHAR(150),
	IN `ptermo` INT
)
    NO SQL
BEGIN

IF((SELECT COUNT(`idRegistro`) FROM `FiltroCadUnicoBeneficio` WHERE `NIS` = pnis) = 0) THEN

	IF((SELECT COUNT(`id_cadastro`) FROM `beneficio_negado` WHERE CAST(AES_DECRYPT(`nis`,'semas2021') AS char(255)) = pnis) != 0) THEN
	SET @retorno := 2;
	SELECT @retorno;
	
	ELSEIF((SELECT COUNT(`id_cadastro`) FROM `beneficio_negado` WHERE CAST(AES_DECRYPT(`nome`,'semas2021') AS char(255)) = pnome) != 0) THEN
	SET @retorno := 2;
	SELECT @retorno;
	
	ELSEIF((SELECT COUNT(`id_cadastro`) FROM `beneficio_negado` WHERE CAST(AES_DECRYPT(`cpf`,'semas2021') AS char(255)) = pcpf) != 0) THEN
	SET @retorno := 2;
	SELECT @retorno;
	
	ELSE
INSERT INTO `beneficio_negado` (`nis`, `nome`, `data_nascimento`, `cpf`, `email`, `telefone`, `cep`, `endereco`, `numero`, `complemento`, `bairro`, `termo`) VALUES(`pnis`, `pnome`, `pdatanascimento`,`pcpf`, `pemail`, `ptelefone`, `pcep`, `pendereco`, `pnumero`, `pcomplemento`, `pbairro`, `ptermo`);

UPDATE `beneficio_negado` SET `nis`= AES_ENCRYPT(`nis`,'semas2021'),`nome`= AES_ENCRYPT(`nome`,'semas2021'),`cpf`= AES_ENCRYPT(`cpf`,'semas2021'),`email`= AES_ENCRYPT(`email`,'semas2021'),`telefone`= AES_ENCRYPT(`telefone`,'semas2021') WHERE id_cadastro = last_insert_id();

SET @retorno := 1;
SELECT @retorno;

	END IF;

ELSEIF((SELECT COUNT(`idRegistro`) FROM `FiltroCadUnicoBeneficio` WHERE `Nome` LIKE pnome) = 0) THEN
	IF((SELECT COUNT(`id_cadastro`) FROM `beneficio_negado` WHERE CAST(AES_DECRYPT(`nis`,'semas2021') AS char(255)) = pnis) != 0) THEN
	SET @retorno := 2;
	SELECT @retorno;
	
	ELSEIF((SELECT COUNT(`id_cadastro`) FROM `beneficio_negado` WHERE CAST(AES_DECRYPT(`nome`,'semas2021') AS char(255)) = pnome) != 0) THEN
	SET @retorno := 2;
	SELECT @retorno;
	
	ELSEIF((SELECT COUNT(`id_cadastro`) FROM `beneficio_negado` WHERE CAST(AES_DECRYPT(`cpf`,'semas2021') AS char(255)) = pcpf) != 0) THEN
	SET @retorno := 2;
	SELECT @retorno;
	
	ELSE
INSERT INTO `beneficio_negado` (`nis`, `nome`, `data_nascimento`, `cpf`, `email`, `telefone`, `cep`, `endereco`, `numero`, `complemento`, `bairro`, `termo`) VALUES(`pnis`, `pnome`, `pdatanascimento`,`pcpf`, `pemail`, `ptelefone`, `pcep`, `pendereco`, `pnumero`, `pcomplemento`, `pbairro`, `ptermo`);

UPDATE `beneficio_negado` SET `nis`= AES_ENCRYPT(`nis`,'semas2021'),`nome`= AES_ENCRYPT(`nome`,'semas2021'),`cpf`= AES_ENCRYPT(`cpf`,'semas2021'),`email`= AES_ENCRYPT(`email`,'semas2021'),`telefone`= AES_ENCRYPT(`telefone`,'semas2021') WHERE id_cadastro = last_insert_id();

SET @retorno := 1;
SELECT @retorno;

	END IF;

ELSEIF((SELECT COUNT(`idRegistro`) FROM `FiltroCadUnicoBeneficio` WHERE `CPF` = pcpf) = 0) THEN
	IF((SELECT COUNT(`id_cadastro`) FROM `beneficio_negado` WHERE CAST(AES_DECRYPT(`nis`,'semas2021') AS char(255)) = pnis) != 0) THEN
	SET @retorno := 2;
	SELECT @retorno;
	
	ELSEIF((SELECT COUNT(`id_cadastro`) FROM `beneficio_negado` WHERE CAST(AES_DECRYPT(`nome`,'semas2021') AS char(255)) = pnome) != 0) THEN
	SET @retorno := 2;
	SELECT @retorno;
	
	ELSEIF((SELECT COUNT(`id_cadastro`) FROM `beneficio_negado` WHERE CAST(AES_DECRYPT(`cpf`,'semas2021') AS char(255)) = pcpf) != 0) THEN
	SET @retorno := 2;
	SELECT @retorno;
	
	ELSE
	
INSERT INTO `beneficio_negado` (`nis`, `nome`, `data_nascimento`, `cpf`, `email`, `telefone`, `cep`, `endereco`, `numero`, `complemento`, `bairro`, `termo`) VALUES(`pnis`, `pnome`, `pdatanascimento`,`pcpf`, `pemail`, `ptelefone`, `pcep`, `pendereco`, `pnumero`, `pcomplemento`, `pbairro`, `ptermo`);

UPDATE `beneficio_negado` SET `nis`= AES_ENCRYPT(`nis`,'semas2021'),`nome`= AES_ENCRYPT(`nome`,'semas2021'),`cpf`= AES_ENCRYPT(`cpf`,'semas2021'),`email`= AES_ENCRYPT(`email`,'semas2021'),`telefone`= AES_ENCRYPT(`telefone`,'semas2021') WHERE id_cadastro = last_insert_id();

SET @retorno := 1;
SELECT @retorno;

	END IF;

ELSE

	IF((SELECT COUNT(`id_cadastro`) FROM `beneficio_municipal` WHERE CAST(AES_DECRYPT(`nis`,'semas2021') AS char(255)) = pnis) != 0) THEN
	SET @retorno := 4;
	SELECT @retorno;
	
	ELSEIF((SELECT COUNT(`id_cadastro`) FROM `beneficio_municipal` WHERE CAST(AES_DECRYPT(`nome`,'semas2021') AS char(255)) = pnome) != 0) THEN
	SET @retorno := 4;
	SELECT @retorno;
	
	ELSEIF((SELECT COUNT(`id_cadastro`) FROM `beneficio_municipal` WHERE CAST(AES_DECRYPT(`cpf`,'semas2021') AS char(255)) = pcpf) != 0) THEN
	SET @retorno := 4;
	SELECT @retorno;
	
	ELSE
	
INSERT INTO `beneficio_municipal` (`nis`, `nome`, `data_nascimento`, `cpf`, `email`, `telefone`, `cep`, `endereco`, `numero`, `complemento`, `bairro`, `termo`) VALUES(`pnis`, `pnome`, `pdatanascimento`,`pcpf`, `pemail`, `ptelefone`, `pcep`, `pendereco`, `numero`, `pendereco`, `pbairro`, `ptermo`);
	END IF;
END IF;
UPDATE `beneficio_municipal` SET `nis`= AES_ENCRYPT(`nis`,'semas2021'),`nome`= AES_ENCRYPT(`nome`,'semas2021'),`cpf`= AES_ENCRYPT(`cpf`,'semas2021'),`email`= AES_ENCRYPT(`email`,'semas2021'),`telefone`= AES_ENCRYPT(`telefone`,'semas2021') WHERE id_cadastro = last_insert_id();

SET @retorno := 3;
SELECT @retorno;
SELECT
CAST(AES_DECRYPT(`nis`,'semas2021') AS char(255)) AS NIS,
CAST(AES_DECRYPT(`nome`,'semas2021') AS char(255)) AS NOME,
CAST(AES_DECRYPT(`cpf`,'semas2021') AS char(255)) AS CPF,
CAST(AES_DECRYPT(`email`,'semas2021') AS char(255)) AS EMAIL,
CAST(AES_DECRYPT(`telefone`,'semas2021') AS char(255)) AS TELEFONE,
`cep`,
`endereco`,
`bairro`,
`cidade`,
`pessoas`,
`renda`,
`cadastro`,`termo`
FROM `beneficio_municipal`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_protocolo_saida`(IN `pdocumento_id` INT, IN `plocal_destino` INT, IN `psaida_nota` TEXT CHARSET utf8, IN `pcadastrante` INT, IN `pid_entrada` INT)
BEGIN
	INSERT INTO `controle_entrada`(`registro`, `documento`) 
    VALUES ((SELECT DISTINCT(entrada_protocolo.local_destino) FROM `entrada_protocolo` WHERE `entrada_id`=pid_entrada),pdocumento_id);
    INSERT INTO `entrada_protocolo`(`documento_id`,`local_origem`, `local_destino`,`cadastrante`) 
    VALUES (pdocumento_id, (SELECT `registro` FROM `controle_entrada` WHERE `id_registro` = last_insert_id()), plocal_destino, pcadastrante);
	INSERT INTO `saida_protocolo`(`id_entrada`,`documento_id`, `local_destino`, `saida_status`, `saida_nota`, `cadastrante`)
	VALUES ((SELECT `entrada_id` FROM `entrada_protocolo` WHERE `entrada_id` = last_insert_id()), pdocumento_id, plocal_destino, 1, psaida_nota ,pcadastrante);
	UPDATE `saida_protocolo`
	SET `saida_status`= 0
	WHERE `saida_id` != last_insert_id()  AND `documento_id` = pdocumento_id;
	TRUNCATE TABLE `controle_entrada`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_excluir_permissao2`(IN `pidgrupo` INT, IN `pnomegrupo` VARCHAR(255), IN `pcontrole` INT )
BEGIN
IF(pcontrole = 1) THEN
	DELETE FROM `permissao_gestao` WHERE `grupoidpermissao` = `pidgrupo`;
END IF;
IF(pcontrole = 2) THEN
	DELETE FROM `permissao_atendimento` WHERE `grupoidpermissao` = `pidgrupo`;
END IF;
IF(pcontrole = 3) THEN
	DELETE FROM `permissao_audiencia` WHERE `grupoidpermissao` = `pidgrupo`;
END IF;
IF(pcontrole = 4) THEN
	DELETE FROM `permissao_fiscalizacao` WHERE `grupoidpermissao` = `pidgrupo`;
END IF;
IF(pcontrole = 5) THEN
	DELETE FROM `permissao_administrativo` WHERE `grupoidpermissao` = `pidgrupo`;
END IF;
IF(pcontrole = 6) THEN
	DELETE FROM `permissao_coordenacao` WHERE `grupoidpermissao` = `pidgrupo`;
END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_tabela`(IN `psetor` VARCHAR(255))
BEGIN
SET @SQL = CONCAT('CREATE TABLE ',CONCAT(LOWER(psetor)),'(`idpermisao` int(11) NOT NULL, `grupoidpermissao` int(11) NOT NULL, `grupopermisao` varchar(255) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;');
PREPARE stmt FROM @SQL;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
SET @SQL2 = CONCAT('ALTER TABLE ' ,CONCAT(LOWER(psetor)),' ADD PRIMARY KEY (`idpermisao`); ');
PREPARE stmt FROM @SQL2;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
SET @SQL3 = CONCAT('ALTER TABLE ' ,CONCAT(LOWER(psetor)),' MODIFY `idpermisao` int(11) NOT NULL AUTO_INCREMENT; ');
PREPARE stmt FROM @SQL3;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`semas`@`%` PROCEDURE `sp_novo_documento_protocolo`(IN `pdocumento` VARCHAR(255))
BEGIN
IF(pdocumento !='') THEN
	INSERT INTO `tipo_doc_protocolo`(`tipodocumento`) VALUES (pdocumento);
END IF;
END$$
DELIMITER ;
